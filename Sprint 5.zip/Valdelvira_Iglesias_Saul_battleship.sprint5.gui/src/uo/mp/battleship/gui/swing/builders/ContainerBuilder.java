package uo.mp.battleship.gui.swing.builders;

import java.awt.Container;

public interface ContainerBuilder {

	Container build();

}
