/*
 * 
 * @author Sa�l Valdelvira Iglesias (UO283685)
 * @version 16/04/2021
 *
 */
package uo.mp.battleship.session;

/** 
 * @author Sa�l Valdelvira Iglesias (UO283685)
 * @version 16/04/2021
 */
public enum GameLevel {	
	PLANET, OCEAN, SEA
}
