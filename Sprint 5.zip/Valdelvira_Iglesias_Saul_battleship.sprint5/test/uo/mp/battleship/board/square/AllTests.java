/*
 * 
 * @author Sa�l Valdelvira Iglesias (UO283685)
 * @version 16/04/2021
 *
 */
package uo.mp.battleship.board.square;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * @author Sa�l
 *
 */
@RunWith(Suite.class)
@SuiteClasses({ ShootAtTest.class })
public class AllTests {

}
