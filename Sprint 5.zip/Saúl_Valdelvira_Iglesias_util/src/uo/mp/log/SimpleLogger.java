package uo.mp.log;

public interface SimpleLogger {
	void log(Exception ex);
}
