package uo.mp.collections.iterator;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ LinkedListIteratorHasNextTest.class, LinkedListIteratorNextTest.class, LinkedListIteratorRemove.class })
public class AllLinkedListIteratorTests {

}
