package uo.mp.collections.iterator;



import org.junit.Before;

import uo.mp.collections.LinkedList;
/** 
 * @author Sa�l Valdelvira Iglesias (UO283685)
 * @version 28/03/2021
 */
public class LinkedListIteratorNextTest extends ListIteratorNext{

	@Before
	public void setUp() {
		list= new LinkedList<String>();
	}

}
