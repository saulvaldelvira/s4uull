package uo.mp.collections.list;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import uo.mp.collections.List;
import uo.mp.collections.ArrayList;
import uo.mp.collections.setting.Settings;

public class RemoveFromPositionTests {
	
	private List<Object> list;

	@SuppressWarnings("unchecked")
	@Before
	public void setUp() throws Exception {
		list = Settings.factory.newList();
	}

	/*
	 * CASOS
	 *Remove de la posici�n 0 de una lista con un elemento devuelve el elemento eliminado y la lista queda vac�a
	 *Remove de la posici�n 0 de una lista no vac�a devuelve el elemento eliminado y quita el elemento de la lista
	 *Remove de la posici�n 0 de una lista no vac�a, mueve el resto de elementos una posici�n a la izquierda
	 *Remove de una posici�n existente, devuelve el elemento borrado y se quita el elemento de la lista
	 *Remove de una posici�n existente, mueve los elementos de la derecha una posici�n a la izquierda
	 *Remove de la �ltima posici�n, devuelve el elemento borrado y quita el lemento de la lista
	 *Intentar realizar remove en la posici�n -1 lanza IndexOutOfBoundsException
	 *Intentar realizar remove en la posici�n 0 de una lista vac�a, lanza IndexOutOfBoundsException
     *Intentar realizar remove en la posici�n size() de una lista vac�a, lanza IndexOutOfBoundsException
	 *Intentar realizar remove en la posici�n size() de una lista no vac�a, lanza IndexOutOfBoundsException
	 */
	
	/**
	 * GIVEN una lista con un objeto
	 * WHEN  llamamos a remove(0)
	 * THEN  se elimina ese objeto de la lista
	 */
	@Test
	public void oneObjectList() {
		list = new ArrayList<Object>();
		Object obj = new Object();
		list.add(obj);
		assertEquals(obj,list.remove(0));
		assertEquals(0, list.size());
	}
	
	/**
	 * GIVEN una lista con dos objetos
	 * WHEN  llamamos a remove(0)
	 * THEN  se elimina ese objeto de la lista
	 */
	@Test
	public void moreObjectsList() {
		list = new ArrayList<Object>();
		Object obj1 = new Object();
		Object obj2 = new Object();
		list.add(obj1);
		list.add(obj2);
		assertEquals(obj1,list.remove(0));
		assertEquals(1, list.size());
		assertEquals(obj2, list.get(0));
	}
	
	/**
	 * GIVEN una lista con tres objetos
	 * WHEN  llamamos a remove(0)
	 * THEN  se elimina ese objeto de la lista y el resto se mueven a la izda
	 */
	@Test
	public void moveOthersList() {
		list = new ArrayList<Object>();
		Object obj1 = new Object();
		Object obj2 = new Object();
		Object obj3 = new Object();
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.remove(0);
		assertEquals(obj2, list.get(0));
		assertEquals(obj3, list.get(1));
		
	}
	
	/**
	 * GIVEN una lista con tres objetos
	 * WHEN  llamamos a remove(position)
	 * THEN  se elimina ese objeto de la lista 
	 */
	@Test
	public void existingIndexErase() {
		list = new ArrayList<Object>();
		Object obj1 = new Object();
		Object obj2 = new Object();
		Object obj3 = new Object();
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		assertEquals(obj2,list.remove(1));
		assertEquals(2, list.size());
		
	}

	/**
	 * GIVEN una lista con tres objetos
	 * WHEN  llamamos a remove(0)
	 * THEN  se elimina ese objeto de la lista y el resto se mueven a la izda
	 */
	@Test
	public void existingIndexMove() {
		list = new ArrayList<Object>();
		Object obj1 = new Object();
		Object obj2 = new Object();
		Object obj3 = new Object();
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.remove(1);
		assertEquals(obj1, list.get(0));
		assertEquals(obj3, list.get(1));
		
	}
	
	/**
	 * GIVEN una lista con tres objetos
	 * WHEN  llamamos a remove(lastPosition)
	 * THEN  se elimina ese objeto de la lista
	 */
	@Test
	public void lastPositionErase() {
		list = new ArrayList<Object>();
		Object obj1 = new Object();
		Object obj2 = new Object();
		Object obj3 = new Object();
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.remove(2);
		assertEquals(2, list.size());
	}
	
	/**
	 * GIVEN una lista con tres objetos
	 * WHEN  llamamos a remove(-1)
	 * THEN  salta un error
	 */
	@Test
	(expected=IndexOutOfBoundsException.class)
	public void outOfIndex() {
		list = new ArrayList<Object>();
		Object obj1 = new Object();
		Object obj2 = new Object();
		Object obj3 = new Object();
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.remove(-1);
	}
	
	/**
	 * GIVEN una lista vacia
	 * WHEN  llamamos a remove(0)
	 * THEN  salta un error
	 */
	@Test
	(expected=IndexOutOfBoundsException.class)
	public void empty() {
		list = new ArrayList<Object>();
		list.remove(0);
	}
	
	/**
	 * GIVEN una lista vacia
	 * WHEN  llamamos a remove(size)
	 * THEN  salta un error
	 */
	@Test
	(expected=IndexOutOfBoundsException.class)
	public void empty2() {
		list = new ArrayList<Object>();
		list.remove(list.size());
	}
	
	/**
	 * GIVEN una lista con tres objetos
	 * WHEN  llamamos a remove(size)
	 * THEN  salta un error
	 */
	@Test
	(expected=IndexOutOfBoundsException.class)
	public void sizeNotEmpty() {
		list = new ArrayList<Object>();
		Object obj1 = new Object();
		Object obj2 = new Object();
		Object obj3 = new Object();
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.remove(list.size());
	
	}
}
