package uo.mp.collections.queue;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AllArrayQueueTests.class, AllLinkedQueueTests.class })
public class AllQueueTests {

}
