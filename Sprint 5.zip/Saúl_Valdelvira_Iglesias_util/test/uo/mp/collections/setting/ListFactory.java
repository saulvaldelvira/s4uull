package uo.mp.collections.setting;

import uo.mp.collections.List;

public interface ListFactory<T> {

	List<T> newList();

}
