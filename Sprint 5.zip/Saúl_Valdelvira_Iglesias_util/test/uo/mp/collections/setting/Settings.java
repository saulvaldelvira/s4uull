package uo.mp.collections.setting;



public class Settings {

	@SuppressWarnings("rawtypes")
	public static ListFactory factory;
	@SuppressWarnings("rawtypes")
	public static QueueFactory queueFactory;
	@SuppressWarnings("rawtypes")
	public static StackFactory stackFactory;
	
}
